% tt.m
clear; close all; clc;

tmin = 0; tmax = 6;

% 参考（近似连续）用很小的采样间隔
Ts_ref = 1e-4;
[t_ref, x_ref, h_ref] = sample_signals(Ts_ref, tmin, tmax);
y_ref = Ts_ref * conv(x_ref, h_ref);           % 离散卷积近似连续卷积
t_ref_conv = tmin:Ts_ref:2*tmax;

% 解析闭式解（按题意求的分段积分）
t_anal = t_ref_conv;
a = max(1, t_anal - 3);
b = min(3, t_anal - 1);
y_anal = zeros(size(t_anal));
idx = b > a;
y_anal(idx) = (t_anal(idx) - 1) .* (b(idx) - a(idx)) - 0.5 * (b(idx).^2 - a(idx).^2);

% 要比较的采样间隔
Ts_list = [1, 0.5, 0.1, 0.05, 0.01];
errors = zeros(size(Ts_list));

figure(1); hold on; grid on;
plot(t_anal, y_anal, 'k--', 'LineWidth', 1.2, 'DisplayName', '解析解(连续)');

colors = lines(length(Ts_list));
for k = 1:length(Ts_list)
    Ts = Ts_list(k);
    t = tmin:Ts:tmax;
    x = double(t >= 1 & t <= 3);                 % x(t)=1, 1<=t<=3
    h = (t - 1) .* double(t >= 1 & t <= 3);      % h(t)=t-1, 1<=t<=3
    y = Ts * conv(x, h);                         % 离散卷积（矩形法则近似积分）
    t_conv = tmin:Ts:2*tmax;
    % 插值到解析时间轴比较
    y_interp = interp1(t_conv, y, t_anal, 'linear', 0);
    errors(k) = sqrt(mean((y_interp - y_anal).^2));
    plot(t_conv, y, 'Color', colors(k,:), 'DisplayName', sprintf('Ts=%.3f, RMSE=%.4g', Ts, errors(k)));
end
xlabel('t'); ylabel('y(t)'); title('不同采样间隔下离散卷积与解析解对比');
legend('Location','bestoutside');

figure(2);
semilogy(Ts_list, errors, '-o','LineWidth',1.2); grid on;
xlabel('采样间隔 Ts'); ylabel('RMSE (对解析解)'); title('RMSE vs Ts');

% 输出 RMSE 数值
disp('Ts 和 对应 RMSE:');
for k=1:length(Ts_list)
    fprintf('  Ts = %.4f  =>  RMSE = %.6g\n', Ts_list(k), errors(k));
end

% ----- 子函数 -----
function [t,x,h] = sample_signals(Ts, tmin, tmax)
    t = tmin:Ts:tmax;
    x = double(t >= 1 & t <= 3);
    h = (t - 1) .* double(t >= 1 & t <= 3);
end