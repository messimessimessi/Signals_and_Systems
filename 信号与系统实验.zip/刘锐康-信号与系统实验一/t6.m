% t6.m
% 求解二阶常系数齐次微分方程的零输入响应

% 清除工作区变量和命令窗口
clear; clc;

% 使用符号运算求解常系数齐次微分方程
% 定义符号变量：时间t和待定系数C1, C2
syms t C1 C2
% 根据特征根r=-2,-3设定通解形式
y_sym = C1*exp(-2*t) + C2*exp(-3*t);    % 特征根 r=-2,-3

% 建立初始条件方程：
% y(0) = 1 和 y'(0) = 0
eqs = [subs(y_sym,t,0) == 1, subs(diff(y_sym,t),t,0) == 0];
% 求解方程组得到系数C1和C2
sol = solve(eqs, [C1 C2]);
% 简化求解结果
C1v = simplify(sol.C1);
C2v = simplify(sol.C2);

% 将求得的系数代回通解，得到特解
y_sym = simplify(subs(y_sym, [C1 C2], [C1v C2v]));

% 在命令窗口显示解析解结果
disp('解析解 y(t) (t >= 0)：');
disp(y_sym);

% 数值计算和绘图部分
% 创建时间向量，从0到5秒，1000个点
tnum = linspace(0,5,1000);
% 将符号表达式转换为数值，用于绘图
y_num = double(subs(y_sym, t, tnum));

% 创建图形窗口
figure;
% 绘制零输入响应曲线，线宽1.4
plot(tnum, y_num, 'LineWidth',1.4);
% 显示网格
grid on;
% 设置坐标轴标签
xlabel('t'); ylabel('y(t)');
% 设置图形标题，显示具体的解析表达式
title('零输入响应 y(t) = 3e^{-2t} - 2e^{-3t}');
% 设置x轴显示范围
xlim([0 5]);