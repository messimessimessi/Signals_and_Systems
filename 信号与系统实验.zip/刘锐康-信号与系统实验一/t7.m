% t7.m
clear; clc; close all;

% 时间轴（t>=0）
t = linspace(0,10,10001)';   % 列向量

% 解析表达式（因果，t>=0）
h_ana = @(tt) 6*(exp(-2*tt) - exp(-3*tt));            % 冲激响应
s_ana = @(tt) 1 - 3*exp(-2*tt) + 2*exp(-3*tt);       % 阶跃响应
yzs_ana = @(tt) 3*exp(-tt) - 6*exp(-2*tt) + 3*exp(-3*tt); % 零状态响应 (x(t)=e^{-t}u(t))

% 在命令窗口显示解析式（符号形式）
syms ts
h_sym = 6*(exp(-2*ts)-exp(-3*ts));
s_sym = 1 - 3*exp(-2*ts) + 2*exp(-3*ts);
yzs_sym = 3*exp(-ts) - 6*exp(-2*ts) + 3*exp(-3*ts);
disp('解析解：');
disp('冲激响应 h(t) = '); pretty(simplify(h_sym));
disp('阶跃响应 s(t) = '); pretty(simplify(s_sym));
disp('零状态响应 y_{zs}(t) = '); pretty(simplify(yzs_sym));

% 使用传递函数数值验证
sys = tf(6, [1 5 6]);  % H(s)=6/(s^2+5s+6)

% 数值冲激响应与阶跃响应
[h_num, th] = impulse(sys, t);
[s_num, ts_step] = step(sys, t);

% 数值零状态响应（输入 x(t)=e^{-t}u(t)）
u = exp(-t);                      % 输入列向量
y_zs_num = lsim(sys, u, t);       % 零初始条件下的响应

% 绘图：冲激响应
figure;
plot(t, h_ana(t), 'r-', 'LineWidth',1.4); hold on;
plot(th, h_num, 'k--', 'LineWidth',1);
grid on; xlabel('t'); ylabel('h(t)');
title('冲激响应 h(t) —— 解析(红) vs 数值(黑虚)');
legend('解析','数值','Location','northeast');
xlim([0 6]);

% 绘图：阶跃响应
figure;
plot(t, s_ana(t), 'r-', 'LineWidth',1.4); hold on;
plot(ts_step, s_num, 'k--', 'LineWidth',1);
grid on; xlabel('t'); ylabel('s(t)');
title('阶跃响应 s(t) —— 解析(红) vs 数值(黑虚)');
legend('解析','数值','Location','southeast');
xlim([0 6]);

% 绘图：零状态响应（输入 e^{-t}u(t)）
figure;
plot(t, yzs_ana(t), 'r-', 'LineWidth',1.4); hold on;
plot(t, y_zs_num, 'k--', 'LineWidth',1);
grid on; xlabel('t'); ylabel('y_{zs}(t)');
title('零状态响应 y_{zs}(t) (输入 x(t)=e^{-t}u(t)) —— 解析(红) vs 数值(黑虚)');
legend('解析','数值','Location','northeast');
xlim([0 6]);

% 在命令窗口显示解析函数的简单表达
disp('简洁形式：');
fprintf('h(t) = 6(e^{-2t} - e^{-3t}),  t>=0\n');
fprintf('s(t) = 1 - 3 e^{-2t} + 2 e^{-3t},  t>=0\n');
fprintf('y_{zs}(t) = 3 e^{-t} - 6 e^{-2t} + 3 e^{-3t},  t>=0\n');