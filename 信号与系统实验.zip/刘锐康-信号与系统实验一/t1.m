% 1.m
% 生成连续时间轴，从-12到12，步长为0.001（可根据需要调整）
t = -12:0.001:12;   % 连续时间轴（步长可调整）

% 定义单位阶跃函数 u(t)
% 使用匿名函数，当输入x>=0时返回1，否则返回0
% double()函数将逻辑值转换为双精度数值（0或1）
u = @(x) double(x >= 0);

% (1) 绘制信号：x(t) = u(t+1) - 2u(t-2) + u(t-6)
% 该信号由三个阶跃函数组合而成，形成矩形脉冲序列
x1 = u(t+1) - 2*u(t-2) + u(t-6);
% 创建新图形窗口
figure; 
% 绘制信号，设置线宽为1.2
plot(t,x1,'LineWidth',1.2);
% 设置图形标题
title('(1) x(t) = u(t+1) - 2u(t-2) + u(t-6)'); 
% 设置x轴标签
xlabel('t'); 
% 设置y轴标签
ylabel('x(t)'); 
% 显示网格
grid on;
% 设置坐标轴范围：x轴从-12到12，y轴在信号最小值-0.5到最大值+0.5之间
axis([-12 12 min(x1)-0.5 max(x1)+0.5]);

% (2) 绘制不同频率的正弦信号：x(t) = sin(w0 * t)
% 定义四个不同的角频率值
wlist = [pi/4, 3*pi/4, 5*pi/4, 7*pi/4];
% 循环绘制每个频率对应的正弦信号
for k = 1:length(wlist)
    % 获取当前角频率
    w0 = wlist(k);
    % 计算正弦信号
    x2 = sin(w0 * t);
    % 创建新图形窗口
    figure; 
    % 绘制正弦信号，线宽为1
    plot(t, x2, 'LineWidth',1);
    % 设置标题，显示当前角频率值（保留3位小数）
    title(sprintf('(2) x(t)=sin(\\omega_0 t), \\omega_0 = %.3f (rad)', w0));
    % 设置坐标轴标签
    xlabel('t'); ylabel('x(t)'); 
    % 显示网格
    grid on; 
    % 设置坐标轴范围：x轴从-12到12，y轴从-1.2到1.2
    axis([-12 12 -1.2 1.2]);
end

% (3) 绘制周期矩形脉冲信号
% 参数定义：周期T=4，脉冲宽度duty=2，脉冲幅度A=2
T = 4; duty = 2; A = 2;
% 初始化信号向量，全零
x3 = zeros(size(t));
% 通过循环进行周期延拓，n从-10到10，覆盖足够多的周期
for n = -10:10
    % 计算当前脉冲的中心位置
    center = n*T; % 脉冲中心
    % 在当前周期位置添加矩形脉冲
    % 逻辑判断：时间在[center-duty/2, center+duty/2)区间内为脉冲区域
    x3 = x3 + A * ((t >= (center - duty/2)) & (t < (center + duty/2)));
end
% 创建新图形窗口
figure; 
% 绘制周期矩形脉冲信号，线宽1.2
plot(t, x3, 'LineWidth',1.2);
% 设置标题和坐标轴标签
title('(3) 周期矩形脉冲'); xlabel('t'); ylabel('x(t)'); 
% 显示网格
grid on; 
% 设置坐标轴范围：x轴从-12到12，y轴从-0.5到2.5
axis([-12 12 -0.5 2.5]);

% (4) 绘制抽样函数信号：x(t) = Sa(10*pi*t)
% 计算抽样函数的参数
x4_arg = 10*pi*t;
% 计算抽样函数值：sin(x)/x
x4 = sin(x4_arg)./x4_arg;
% 处理分母为零的情况（当t=0时），此时Sa(0)=1
x4(x4_arg == 0) = 1;
% 创建新图形窗口
figure; 
% 绘制抽样函数信号，线宽1.2
plot(t, x4, 'LineWidth',1.2);
% 设置标题（使用LaTeX格式显示数学公式）
title('(4) x(t)=Sa(10\pi t)'); 
% 设置坐标轴标签
xlabel('t'); ylabel('x(t)'); 
% 显示网格
grid on; 
% 设置坐标轴范围：x轴从-12到12，y轴在信号最小值-0.2到最大值+0.2之间
axis([-12 12 min(x4)-0.2 max(x4)+0.2]);

% (5) 绘制衰减正弦信号：x(t) = e^{-t} * sin(10*pi*t)
% 计算衰减正弦信号：指数衰减项与正弦项的乘积
x5 = exp(-t) .* sin(10*pi*t);
% 创建新图形窗口
figure; 
% 绘制衰减正弦信号，线宽1.2
plot(t, x5, 'LineWidth',1.2);
% 设置标题（使用LaTeX格式显示数学公式）
title('(5) x(t)=e^{-t} sin(10\pi t)'); 
% 设置坐标轴标签
xlabel('t'); ylabel('x(t)'); 
% 显示网格
grid on; 
% 设置坐标轴范围：x轴从-12到12，y轴在信号最小值-0.2到最大值+0.2之间
axis([-12 12 min(x5)-0.2 max(x5)+0.2]);

% (6) 绘制复指数信号：x(t) = e^{(-1 + j10\pi) t}
% 计算复指数信号，包含实部和虚部
x6 = exp((-1 + 1i*10*pi) * t);
% 创建新图形窗口
figure;
% 创建2行1列的子图，当前显示第1个子图（实部）
subplot(3,1,1); 
% 绘制实部信号，蓝色，线宽1.2
plot(t, real(x6),'b','LineWidth',1.2); 
% 设置标题
title('(6) 实部: Re{e^{(-1+j10\pi)t}}'); 
% 设置坐标轴标签
xlabel('t'); ylabel('Re'); 
% 显示网格
grid on;
% 创建2行1列的子图，当前显示第2个子图（虚部）
subplot(3,1,2); 
% 绘制虚部信号，红色，线宽1.2
plot(t, imag(x6),'r','LineWidth',1.2); 
% 设置标题
title('(6) 虚部: Im{e^{(-1+j10\pi)t}}'); 
% 设置坐标轴标签
xlabel('t'); ylabel('Im'); 
% 显示网格
grid on;
% 创建2行1列的图
subplot(3,1,3); 
% 绘制信号，绿色，线宽1.2
plot(t, x6,'g','LineWidth',1.2); 
% 设置标题
title('(6) x(t) = exp((-1 + 1i*10*pi) * t)'); 
% 设置坐标轴标签
xlabel('t'); ylabel('x(t)'); 
% 显示网格
grid on;