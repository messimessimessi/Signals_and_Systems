% t9.m
clear; clc; close all;

% 时间轴（t>=0）
t = linspace(0,1,1001)';    % 若需观察更长时间可增大上限，但系统不稳定会发散

% 传递函数 H(s)=6/(s^2 -5s +6)  （注意极点 s=2,3，不稳定）
num = 6;
den = [1 -5 6];
sys = tf(num, den);

% 解析求解（部分分式求逆Laplace）
syms s ts
Hs = 6 / ( (s-2)*(s-3) );
% 冲激响应 h(t)
h_sym = ilaplace(Hs, s, ts);
h_fun = matlabFunction(h_sym, 'Vars', ts);

% 阶跃响应 s(t) = ∫_0^t h(τ) dτ
s_sym = int(h_sym, ts, 0, ts);
s_fun = matlabFunction(s_sym, 'Vars', ts);

% 零状态响应: X(s)=1/(s+1), Y(s)=H(s)*X(s)
Ys = Hs / (s + 1);
y_zs_sym = ilaplace(Ys, s, ts);
y_zs_fun = matlabFunction(y_zs_sym, 'Vars', ts);

% 在命令窗口显示解析表达式
disp('解析结果（t>=0）：');
fprintf('h(t) = %s\n', char(simplify(h_sym)));
fprintf('s(t) = %s\n', char(simplify(s_sym)));
fprintf('y_{zs}(t) = %s\n', char(simplify(y_zs_sym)));

% 数值验证
[h_num, th] = impulse(sys, t);
[s_num, ts_step] = step(sys, t);
u = exp(-t);                   % 输入 x(t)=e^{-t} u(t)
y_zs_num = lsim(sys, u, t);    % 零初始条件下的响应

% 绘图：冲激响应
figure;
plot(t, h_fun(t), 'r-', 'LineWidth',1.4); hold on;
plot(th, h_num, 'k--', 'LineWidth',1);
grid on; xlabel('t'); ylabel('h(t)');
title('冲激响应 h(t) — 解析(红) vs 数值(黑虚)'); legend('解析','数值');
xlim([0 max(t)]);

% 绘图：阶跃响应
figure;
plot(t, s_fun(t), 'r-', 'LineWidth',1.4); hold on;
plot(ts_step, s_num, 'k--', 'LineWidth',1);
grid on; xlabel('t'); ylabel('s(t)');
title('阶跃响应 s(t) — 解析(红) vs 数值(黑虚)'); legend('解析','数值');
xlim([0 max(t)]);

% 绘图：零状态响应（输入 e^{-t}u(t)）
figure;
plot(t, y_zs_fun(t), 'r-', 'LineWidth',1.4); hold on;
plot(t, y_zs_num, 'k--', 'LineWidth',1);
grid on; xlabel('t'); ylabel('y_{zs}(t)');
title('零状态响应 y_{zs}(t) (x(t)=e^{-t}u(t)) — 解析(红) vs 数值(黑虚)');
legend('解析','数值');
xlim([0 max(t)]);