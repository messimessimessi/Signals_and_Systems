% t4.m
% 信号变换演示脚本：展示信号的时间反转、缩放和仿射变换

% 定义连续时间轴，从-12到12，步长为0.001，用于高精度绘制连续信号
t = -12:0.001:12; % 时间轴

% 定义单位阶跃函数 u(t)
% 使用匿名函数，当输入x>=0时返回1，否则返回0
u = @(x) double(x >= 0); % 单位阶跃函数 u(t)

% 定义原信号：x(t) = (t+1)[u(t)-u(t-4)]
% 这是一个在区间[0,4]上的斜坡信号，从(0,1)到(4,5)的直线
x = (t + 1) .* (u(t) - u(t - 4));

% 信号变换计算
% 时间反转：x(-t)，将信号关于y轴镜像翻转
x_neg = ((-t) + 1) .* (u(-t) - u(-t - 4)); % x(-t)

% 时间缩放：x(0.5t)，将信号在时间轴上展宽2倍
x_scale = (0.5*t + 1) .* (u(0.5*t) - u(0.5*t - 4)); % x(0.5 t)

% 仿射变换：x(3-2t)，包含时间反转、缩放和平移的复合变换
% 3-2t = -2(t-1.5)，表示先反转，再2倍压缩，最后右移1.5单位
x_affine = ((3 - 2*t) + 1) .* (u(3 - 2*t) - u(3 - 2*t - 4)); % x(3 - 2t)

% 创建图形窗口并设置属性
% 'Name'设置窗口名称，'NumberTitle'关闭数字标题
% 'Units'设置为归一化单位，'Position'设置窗口位置和大小[左下角x,y,宽度,高度]
figure('Name','信号及其变换','NumberTitle','off','Units','normalized','Position',[0.1 0.1 0.8 0.7]);

% 第1个子图：原始信号 x(t)
subplot(2,2,1);
% 绘制原始信号，蓝色，线宽1.2
plot(t, x, 'b','LineWidth',1.2); 
% 显示网格
grid on;
% 设置标题和坐标轴标签
title('x(t)=(t+1)[u(t)-u(t-4)]'); xlabel('t'); ylabel('x(t)');
% 设置坐标轴范围，使用所有信号的最小最大值乘以1.1作为边界
axis([-12 12 1.1*min([x,x_neg,x_scale,x_affine]) 1.1*max([x,x_neg,x_scale,x_affine])]);

% 第2个子图：时间反转信号 x(-t)
subplot(2,2,2);
% 绘制时间反转信号，红色，线宽1.2
plot(t, x_neg, 'r','LineWidth',1.2); 
% 显示网格
grid on;
% 设置标题和坐标轴标签
title('x(-t)'); xlabel('t'); ylabel('x(-t)'); 
% 设置坐标轴范围，与第一个子图保持一致便于比较
axis([-12 12 1.1*min([x,x_neg,x_scale,x_affine]) 1.1*max([x,x_neg,x_scale,x_affine])]);

% 第3个子图：时间缩放信号 x(0.5t)
subplot(2,2,3);
% 绘制时间缩放信号，绿色，线宽1.2
plot(t, x_scale, 'g','LineWidth',1.2); 
% 显示网格
grid on;
% 设置标题和坐标轴标签
title('x(0.5t)'); xlabel('t'); ylabel('x(0.5t)'); 
% 设置坐标轴范围，与第一个子图保持一致便于比较
axis([-12 12 1.1*min([x,x_neg,x_scale,x_affine]) 1.1*max([x,x_neg,x_scale,x_affine])]);

% 第4个子图：仿射变换信号 x(3-2t)
subplot(2,2,4);
% 绘制仿射变换信号，洋红色，线宽1.2
plot(t, x_affine, 'm','LineWidth',1.2); 
% 显示网格
grid on;
% 设置标题和坐标轴标签
title('x(3-2t)'); xlabel('t'); ylabel('x(3-2t)'); 
% 设置坐标轴范围，与第一个子图保持一致便于比较
axis([-12 12 1.1*min([x,x_neg,x_scale,x_affine]) 1.1*max([x,x_neg,x_scale,x_affine])]);% t4.m
% 信号变换演示脚本：展示信号的时间反转、缩放和仿射变换

% 定义连续时间轴，从-12到12，步长为0.001，用于高精度绘制连续信号
t = -12:0.001:12; % 时间轴

% 定义单位阶跃函数 u(t)
% 使用匿名函数，当输入x>=0时返回1，否则返回0
u = @(x) double(x >= 0); % 单位阶跃函数 u(t)

% 定义原信号：x(t) = (t+1)[u(t)-u(t-4)]
% 这是一个在区间[0,4]上的斜坡信号，从(0,1)到(4,5)的直线
x = (t + 1) .* (u(t) - u(t - 4));

% 信号变换计算
% 时间反转：x(-t)，将信号关于y轴镜像翻转
x_neg = ((-t) + 1) .* (u(-t) - u(-t - 4)); % x(-t)

% 时间缩放：x(0.5t)，将信号在时间轴上展宽2倍
x_scale = (0.5*t + 1) .* (u(0.5*t) - u(0.5*t - 4)); % x(0.5 t)

% 仿射变换：x(3-2t)，包含时间反转、缩放和平移的复合变换
% 3-2t = -2(t-1.5)，表示先反转，再2倍压缩，最后右移1.5单位
x_affine = ((3 - 2*t) + 1) .* (u(3 - 2*t) - u(3 - 2*t - 4)); % x(3 - 2t)

% 创建图形窗口并设置属性
% 'Name'设置窗口名称，'NumberTitle'关闭数字标题
% 'Units'设置为归一化单位，'Position'设置窗口位置和大小[左下角x,y,宽度,高度]
figure('Name','信号及其变换','NumberTitle','off','Units','normalized','Position',[0.1 0.1 0.8 0.7]);

% 第1个子图：原始信号 x(t)
subplot(2,2,1);
% 绘制原始信号，蓝色，线宽1.2
plot(t, x, 'b','LineWidth',1.2); 
% 显示网格
grid on;
% 设置标题和坐标轴标签
title('x(t)=(t+1)[u(t)-u(t-4)]'); xlabel('t'); ylabel('x(t)');
% 设置坐标轴范围，使用所有信号的最小最大值乘以1.1作为边界
axis([-12 12 1.1*min([x,x_neg,x_scale,x_affine]) 1.1*max([x,x_neg,x_scale,x_affine])]);

% 第2个子图：时间反转信号 x(-t)
subplot(2,2,2);
% 绘制时间反转信号，红色，线宽1.2
plot(t, x_neg, 'r','LineWidth',1.2); 
% 显示网格
grid on;
% 设置标题和坐标轴标签
title('x(-t)'); xlabel('t'); ylabel('x(-t)'); 
% 设置坐标轴范围，与第一个子图保持一致便于比较
axis([-12 12 1.1*min([x,x_neg,x_scale,x_affine]) 1.1*max([x,x_neg,x_scale,x_affine])]);

% 第3个子图：时间缩放信号 x(0.5t)
subplot(2,2,3);
% 绘制时间缩放信号，绿色，线宽1.2
plot(t, x_scale, 'g','LineWidth',1.2); 
% 显示网格
grid on;
% 设置标题和坐标轴标签
title('x(0.5t)'); xlabel('t'); ylabel('x(0.5t)'); 
% 设置坐标轴范围，与第一个子图保持一致便于比较
axis([-12 12 1.1*min([x,x_neg,x_scale,x_affine]) 1.1*max([x,x_neg,x_scale,x_affine])]);

% 第4个子图：仿射变换信号 x(3-2t)
subplot(2,2,4);
% 绘制仿射变换信号，洋红色，线宽1.2
plot(t, x_affine, 'm','LineWidth',1.2); 
% 显示网格
grid on;
% 设置标题和坐标轴标签
title('x(3-2t)'); xlabel('t'); ylabel('x(3-2t)'); 
% 设置坐标轴范围，与第一个子图保持一致便于比较
axis([-12 12 1.1*min([x,x_neg,x_scale,x_affine]) 1.1*max([x,x_neg,x_scale,x_affine])]);