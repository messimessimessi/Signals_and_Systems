% t3.m
% 抽样函数(Sa函数)相关信号绘制脚本

% 定义连续时间轴，从-12到12，步长为0.001，用于高精度绘制连续信号
t = -12:0.001:12;                  % 连续时间轴

% 定义抽样函数 Sa(x) = sin(x)/x
% 使用匿名函数定义Sa函数
Sa = @(x) (sin(x)./x);             % 定义 Sa(x)=sin(x)/x

% 处理 x==0 处的特殊情况（避免除零错误）
% 找出时间轴上t=0的位置
x0 = (t==0);
% 计算Sa函数在所有时间点的值
saval = Sa(t);
% 将t=0处的值设置为1（因为lim(x→0) sin(x)/x = 1）
saval(x0) = 1;

% (1) 绘制信号：x(t) = Sa(t) × sin(2πt)
% Sa函数与2π频率正弦函数的乘积
x1 = saval .* sin(2*pi*t);
% 创建新图形窗口
figure;
% 绘制信号，设置线宽为1.2
plot(t, x1, 'LineWidth',1.2);
% 显示网格
grid on;
% 设置标题，使用LaTeX格式显示数学公式
title('(1) x(t) = Sa(t) \times sin(2\pi t)');
% 设置坐标轴标签
xlabel('t'); ylabel('x(t)');
% 设置坐标轴范围：x轴从-12到12，y轴在信号最小值的1.1倍到最大值的1.1倍之间
axis([-12 12 1.1*min(x1) 1.1*max(x1)]);

% (2) 绘制信号：x(t) = Sa(t) + sin(2πt)
% Sa函数与2π频率正弦函数的加法
x2 = saval + sin(2*pi*t);
% 创建新图形窗口
figure;
% 绘制信号，设置线宽为1.2
plot(t, x2, 'LineWidth',1.2);
% 显示网格
grid on;
% 设置标题，使用LaTeX格式显示数学公式
title('(2) x(t) = Sa(t) + sin(2\pi t)');
% 设置坐标轴标签
xlabel('t'); ylabel('x(t)');
% 设置坐标轴范围：x轴从-12到12，y轴在信号最小值的1.1倍到最大值的1.1倍之间
axis([-12 12 1.1*min(x2) 1.1*max(x2)]);